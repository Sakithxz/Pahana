# Pahana — prototype

Front-end prototype of a campus assignment-assistance platform.

Open `index.html` in any modern browser (no build step).

Demo admin: admin@pahana.lk / Admin@123 (footer "Staff" link).

Notes: data lives in browser localStorage only; files are limited to 2 MB; this is a UI/flow prototype, not a production backend.
